/** @format */

// TODO write function to detect s3 events and send to ingestor
module.exports.sendS3EventToIngestor = function () {
  console.log('test')
}
